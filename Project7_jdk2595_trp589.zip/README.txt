﻿Project 7: Local Network Chat Client

Authors: Jake Klovenski jdk2595
		 Tiraj Parikh trp589

Files included: src/assignment7/ClientMain.java
				src/assignment7/ClientObserver.java
				src/assignment7/ServerMain.java
				ChatServer.jar
				ChatClient.jar
				README.txt (this) 
				README.pdf

Testing:
	We tested using a combination of Linux and Windows programming environments. We tested to ensure that private messages were not viewed by anyone other than the intended recipient and that the groups were exclusive, ie if you are not in group A you cannot see messages being sent to group A. We insured that these features held true between the two operating systems. We were unfortunately unable to test in a Mac environment because neither of us owns a Macintosh system, we do believe however, that since OSX is UNIX based like Linux it will function in a similiar manner.

Git URL: https://github.com/traj30/Project-7.git
